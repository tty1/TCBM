#!/bin/bash

#cd ~
#mkdir .tcbm
#cd .tcbm
#mkdir client
#cd client
#mkdir tmp
#cd tmp
#mkdir job

USE_THIS_SLAVE=Yes
PROCESSING=No


rm ~/.tcbm/slave/last_slavelog.txt
rm ~/.tcbm/slave/slavelog.txt

last_slavelog=STARTUPSLAVE
echo
#echo $last_slavelog
echo

echo $last_slavelog >> ~/.tcbm/slave/last_slavelog.txt


#echo  >> ~/.tcbm/slave/slavelog.txt
#echo $last_slavelog >> ~/.tcbm/slave/slavelog.txt
#echo  >> ~/.tcbm/slave/slavelog.txt


while [[ 1 == 1 ]]
do

  last_slavelog=`<~/.tcbm/slave/last_slavelog.txt`

  if [[ $last_slavelog == STARTUPSLAVE ]]
  then

  echo $last_slavelog
  echo $last_slavelog >> ~/.tcbm/slave/slavelog.txt
  fi

  #last_slavelog_line=`tail -n1 ~/.tcbm/slave/slavelog.txt`
  if [[ $last_slavelog == executejob* ]]
  then
  echo $last_slavelog
  echo $last_slavelog >> ~/.tcbm/slave/slavelog.txt
  fi

  if [[ $last_slavelog == standby* ]]
  then
  echo $last_slavelog
  echo $last_slavelog >> ~/.tcbm/slave/slavelog.txt
  fi




olddate=`date`

#standby start
if [[ $USE_THIS_SLAVE == Yes ]] && [[ $PROCESSING == No ]]
then

  if ! [[ -f ~/.tcbm/slave/tmp/job.tcbm ]]
  then

  while ! [[ -f ~/.tcbm/slave/tmp/job.tcbm ]]
  do
  echo standby > ~/.tcbm/slave/slavestatus.txt
  newdate=`date`

  echo standby $olddate $newdate > ~/.tcbm/slave/last_slavelog.txt
#  echo standby $olddate $newdat
sleep 1
  done

fi
#standby end


elif [[ $USE_THIS_SLAVE == Yes ]] && [[ $PROCESSING == No ]]
  then

    #while [[ -f ~/.tcbm/slave/tmp/job.tcbm ]]
    while [[ 1 == 1 ]]
    do
  echo executejob > ~/.tcbm/slave/slavestatus.txt
  #STARTBEFEHL FÜR JOBFILE
  sleep 3
  #STARTBEFEHL FÜR JOBFILE
  newdate=`date`
  echo executejob $olddate $newdate > ~/.tcbm/slave/last_slavelog.txt
  echo executejob $olddate $newdate


  sleep 1
  done

elif [[ $USE_THIS_SLAVE == Yes ]] && [[ $PROCESSING == Yes ]]
  then
  echo at_work > slavestatus.txt
  render


elif [[ $USE_THIS_SLAVE == No ]] && [[ $PROCESSING == Yes ]]
  then
  echo last_job > slavestatus.txt



elif [[ $USE_THIS_SLAVE == No ]] && [[ $PROCESSING == No ]]
  then
  echo off > slavestatus.txt


else
  echo error > slavestatus

fi

done
