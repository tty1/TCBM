if  [[ -f 123 ]]
then
olddate=`date`
    while [[ -f 1234 ]]
    do newdate=`date`
    echo $olddate $newdate
    sleep 2
    done
